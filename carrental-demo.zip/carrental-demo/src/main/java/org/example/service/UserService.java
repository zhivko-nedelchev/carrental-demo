package org.example.service;

public interface UserService {
}
