package org.example.service.impl;

public class UserServiceImpl {
}
