package org.example.repository;


import org.example.entity.Car;

import org.example.entity.Reservation;
import org.example.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;


public interface CarRepository extends JpaRepository<Car, Long> {

    @Repository
    public interface ReservationRepository extends JpaRepository<Reservation, Long> {
        List<Reservation> findAllByUser(User user);

        List<Reservation> findAllByCar(Car car);

        Optional<Reservation> findByIdAndUser(Long id, User user);

        @Query("SELECT r FROM Reservation r WHERE r.car = :car AND ((r.startDate <= :startDate AND r.endDate >= :startDate) OR (r.startDate <= :endDate AND r.endDate >= :endDate) OR (r.startDate >= :startDate AND r.endDate <= :endDate))")
        List<Reservation> findReservationsForCarInDateRange(@Param("car") Car car, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);


    }

}