package org.example.dto;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;
import scala.math.BigDecimal;

@Getter
@Setter
@Component
public class CarDto {
    private Long id;
    @NotBlank
    private String make;
    @NotBlank
    private String model;
    @NotNull
    @Min(2)
    private Integer seats;
    @NotNull
    @Positive
    private BigDecimal pricePerDay;

}
