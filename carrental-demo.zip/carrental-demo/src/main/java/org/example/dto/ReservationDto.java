package org.example.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Getter
@Setter
@Component
public class ReservationDto {
    private Long id;
    @NotNull
    private Long userId;
    @NotNull
    private Long carId;
    @NotNull
    private LocalDate startDate;
    @NotNull
    private LocalDate endDate;
}
